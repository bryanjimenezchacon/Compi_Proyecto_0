#ifndef TRANSLATOR_H
#define TRANSLATOR_H
#endif

#include <stdio.h>


// Datatype Files to work
FILE *data_file;
FILE *code_file;
FILE *translated_file; // Raspberry File 
FILE *rasp_file; // Raspberry File 

void translate();
